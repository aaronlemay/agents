# Intel Report
- Updated: 2026-03-01T04:53:27.089Z
- Block: 38286258
- Wallet: 0x3944793e9EB7C838178c52B66f09B8B24c887AfE
- ETH: 0.184631596644980035
- KILL: 99496423.816180676258933876
- Top threat: 0xcfc1a562b9d05502139dd2c250ed11dd8d0eb6c5 (1289 stacks)

## Top Executable Targets
- Spawn+kill @150 target 0xcFc1A562b9D05502139Dd2c250ed11Dd8d0Eb6c5 bounty 20,200 roi 1.52x
- Spawn+kill @102 target 0xcFc1A562b9D05502139Dd2c250ed11Dd8d0Eb6c5 bounty 19,190 roi 1.44x
- Spawn+kill @102 target 0xcFc1A562b9D05502139Dd2c250ed11Dd8d0Eb6c5 bounty 19,190 roi 1.44x
- Spawn+kill @102 target 0xcFc1A562b9D05502139Dd2c250ed11Dd8d0Eb6c5 bounty 19,190 roi 1.44x
- Spawn+kill @102 target 0xcFc1A562b9D05502139Dd2c250ed11Dd8d0Eb6c5 bounty 19,190 roi 1.44x
- Spawn+kill @102 target 0xcFc1A562b9D05502139Dd2c250ed11Dd8d0Eb6c5 bounty 19,190 roi 1.44x

## Launch Queue (First 3 TX)
- TX1 SPAWN_KILL: stack 150 spawn 666 roi 1.52x on 0xcFc1A562 | executable=true

