require("@nomicfoundation/hardhat-toolbox");
require("dotenv").config();
module.exports = { 
  solidity: "0.8.24", 
  networks: { 
    basesepolia: { 
      url: "https://sepolia.base.org", 
      accounts: [process.env.SNIPER_PK, process.env.FORTRESS_PK, process.env.AFTERSHOCK_PK].filter(Boolean) 
    } 
  } 
};
